var express = require('express');
var router = express.Router();

const Distributors = require('../models/distributors')
const Furits = require('../models/fruits')
const Users = require('../models/users')
const Upload = require('../config/common/upload');

// Lấy danh sách distributors
router.get('/get-list-distributor', async (req, res) => {
    try {
        const data = await Distributors.find().populate();
        res.json({
            status: 200,
            message: "Danh sách distributor",
            data: data
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            status: 500,
            message: "Lỗi khi lấy danh sách distributors"
        });
    }
});

// Lấy danh sách fruits
router.get('/get-all-fruit', async (req, res) => {
    try {
        const data = await Fruits.find().populate();
        res.json({
            status: 200,
            message: "Danh sách fruits",
            data: data
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            status: 500,
            message: "Lỗi khi lấy danh sách fruits"
        });
    }
});

// Thêm distributor
router.post('/add-distributor', async (req, res) => {
    try {
        const { name } = req.body;
        const newDistributor = new Distributors({ name });
        const result = await newDistributor.save();
        res.json({
            status: 200,
            message: "Thêm distributor thành công",
            data: result
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            status: 500,
            message: "Lỗi khi thêm distributor"
        });
    }
});

// Thêm fruit
router.post('/add-fruit', async (req, res) => {
    try {
        const { name, quantity, price, status, image, description, id_distributor } = req.body;
        const newFruit = new Fruits({
            name,
            quantity,
            price,
            status,
            image,
            description,
            id_distributor
        });
        const result = await newFruit.save();
        res.json({
            status: 200,
            message: "Thêm fruit thành công",
            data: result
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            status: 500,
            message: "Lỗi khi thêm fruit"
        });
    }
});

// Lấy danh sách fruits với token xác thực
router.get('/get-list-fruit', async (req, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader?.split(' ')[1];

    if (!token) return res.sendStatus(401); // Unauthorized nếu không có token

    try {
        const payload = JWT.verify(token, SECRETKEY);
        const data = await Fruits.find().populate('id_distributor');
        res.json({
            status: 200,
            message: "Danh sách fruits",
            data: data
        });
    } catch (error) {
        if (error instanceof JWT.TokenExpiredError) return res.sendStatus(401); // Token hết hạn
        console.error(error);
        res.sendStatus(403); // Forbidden nếu token không hợp lệ
    }
});

// Lấy fruit theo ID
router.get('/get-fruit-by-id/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const data = await Fruits.findById(id).populate('id_distributor');
        if (data) {
            res.json({
                status: 200,
                message: "Thông tin fruit",
                data: data
            });
        } else {
            res.status(404).json({
                status: 404,
                message: "Fruit không tồn tại"
            });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({
            status: 500,
            message: "Lỗi khi lấy thông tin fruit"
        });
    }
});

//get fruits by price
router.get('/get-fruit-in-price', async (req, res) => {
    try {
        const { minPrice, maxPrice } = req.query;

        const query = { price: { $gte: minPrice, $lte: maxPrice } };

        const data = await Furits.find(query, "name quantity price id_distributor")
            .populate('id_distributor')
            .sort({ quantity: -1 })
            .skip(0)
            .limit(2)
        res.json({
            'status': 200,
            'messenger': 'Danh sách fruit',
            'data': data
        })
    } catch (error) {
        console.log(error);
    }
})

//get fruit have name a or x
router.get('/get-list-fruit-have-name-a-or-x', async (req, res) => {
    try {
        const query = {
            $or: [
                { name: { $regex: 'A' } },
                { name: { $regex: 'X' } },
            ]
        }


        const data = await Furits.find(query, 'name quantity price id_distributor')
            .populate('id_distributor')

        res.json({
            'status': 200,
            'messenger': 'Danh sách fruit',
            'data': data
        })
    } catch (error) {
        console.log(error);
    }
})

router.put('/update-fruit-by-id/:id', Upload.array('image', 5), async (req, res) => {
    try {
        const { id } = req.params
        const data = req.body;
        const { files } = req;



        let url1;
        const updatefruit = await Furits.findById(id)
        if (files && files.length > 0) {
            url1 = files.map((file) => `${req.protocol}://${req.get("host")}/uploads/${file.filename}`);

        }
        if (url1 == null) {
            url1 = updatefruit.image;
        }

        let result = null;
        if (updatefruit) {
            updatefruit.name = data.name ?? updatefruit.name,
                updatefruit.quantity = data.quantity ?? updatefruit.quantity,
                updatefruit.price = data.price ?? updatefruit.price,
                updatefruit.status = data.status ?? updatefruit.status,


                updatefruit.image = url1,

                updatefruit.description = data.description ?? updatefruit.description,
                updatefruit.id_distributor = data.id_distributor ?? updatefruit.id_distributor,
                result = (await updatefruit.save()).populate("id_distributor");;
        }
        if (result) {
            res.json({
                'status': 200,
                'messenger': 'Cập nhật thành công',
                'data': result
            })
        } else {
            res.json({
                'status': 400,
                'messenger': 'Cập nhật không thành công',
                'data': []
            })
        }
    } catch (error) {
        console.log(error);
    }
})


router.put('/update-distributor-by-id/:id', async (req, res) => {
    try {
        const { id } = req.params
        console.log(id);
        const data = req.body
        const updateDistributor = await Distributors.findById(id)
        let result = null;
        if (updateDistributor) {
            updateDistributor.name = data.name ?? updateDistributor.name

            result = await updateDistributor.save();
        }
        if (result) {
            res.json({
                'status': 200,
                'messenger': 'Cập nhật thành công',
                'data': result
            })
        } else {
            res.json({
                'status': 400,
                'messenger': 'Cập nhật không thành công',
                'data': []
            })
        }
    } catch (error) {
        console.log(error);
    }
})

//delete fruit
router.delete('/destroy-fruit-by-id/:id', async (req, res) => {
    try {
        const { id } = req.params
        const result = (await Furits.findByIdAndDelete(id)).populate('id_distributor');
        if (result) {
            res.json({
                "status": 200,
                "messenger": "Xóa thành công",
                "data": result
            })
        } else {
            res.json({
                "status": 400,
                "messenger": "Lỗi! xóa không thành công",
                "data": []
            })
        }
    } catch (error) {
        console.log(error);
    }
})

router.delete('/destroy-distributor-by-id/:id', async (req, res) => {
    try {
        const { id } = req.params
        const result = await Distributors.findByIdAndDelete(id);
        if (result) {
            res.json({
                "status": 200,
                "messenger": "Xóa thành công",
                "data": result
            })
        } else {
            res.json({
                "status": 400,
                "messenger": "Lỗi! xóa không thành công",
                "data": []
            })
        }
    } catch (error) {
        console.log(error);
    }
})



//upload image
router.post('/add-fruit-with-file-image', Upload.array('image', 5), async (req, res) => {
    //Upload.array('image',5) => up nhiều file tối đa là 5
    //upload.single('image') => up load 1 file
    try {
        const data = req.body; // Lấy dữ liệu từ body
        const { files } = req //files nếu upload nhiều, file nếu upload 1 file
        const urlsImage =
            files.map((file) => `${req.protocol}://${req.get("host")}/uploads/${file.filename}`)
        const newfruit = new Furits({
            name: data.name,
            quantity: data.quantity,
            price: data.price,
            status: data.status,
            image: urlsImage, 
            description: data.description,
            id_distributor: data.id_distributor
        }); //Tạo một đối tượng mới
        const result = (await newfruit.save()).populate("id_distributor"); //Thêm vào database
        if (result) {// Nếu thêm thành công result !null trả về dữ liệu
            res.json({
                "status": 200,
                "messenger": "Thêm thành công",
                "data": result
            })
        } else {// Nếu thêm không thành công result null, thông báo không thành công
            res.json({
                "status": 400,
                "messenger": "Lỗi, thêm không thành công",
                "data": []
            })
        }
    } catch (error) {
        console.log(error);
    }
});

router.post('/add-user', Upload.single('avartar'), async (req, res) => {
    try {
        const data = req.body;
        const file = req.file;
        const imageUrl = `${req.protocol}://${req.get("host")}/uploads/${file.filename}`;

        const newUser = new Users({
            username: data.username,
            password: data.password,
            email: data.email,
            name: data.name,
            avartar: imageUrl,
        });

        const result = await newUser.save();
        if (result) {
            res.json({
                "status": 200,
                "message": "Thêm thành công",
                "data": result
            });
        } else {
            res.json({
                "status": 400,
                "message": "Thêm không thành công",
                "data": []
            });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({
            "status": 500,
            "message": "Đã xảy ra lỗi",
            "data": []
        });
    }
});

router.get('/getAllUser', async (req, res) => {
    try {
        const users = await Users.find();
        res.status(200).json({
            status: 200,
            message: 'Danh sách người dùng',
            data: users
        });
    } catch (error) {
        console.log(error);
    }

})

const Transporter = require('../config/common/mail')
router.post('/register-send-email', Upload.single('avartar'), async (req, res) => {
    try {
        const data = req.body;
        const { file } = req
        const newUser = Users({
            username: data.username,
            password: data.password,
            email: data.email,
            name: data.name,
            avartar: `${req.protocol}://${req.get("host")}/uploads/${file.filename}`,
        })
        const result = await newUser.save()
        if (result) { //Gửi mail
            const mailOptions = {
                from: "thanghtph31577@fpt.edu.vn", //email gửi đi
                to: result.email, // email nhận
                subject: "Đăng ký thành công", //subject
                text: "Cảm ơn bạn đã đăng ký", // nội dung mail
            };
            // Nếu thêm thành công result !null trả về dữ liệu
            await Transporter.sendMail(mailOptions); // gửi mail
            res.json({
                "status": 200,
                "messenger": "Thêm thành công",
                "data": result
            })
        } else {// Nếu thêm không thành công result null, thông báo không thành công
            res.json({
                "status": 400,
                "messenger": "Lỗi, thêm không thành công",
                "data": []
            })
        }
    } catch (error) {
        console.log(error);
    }
})


const JWT = require('jsonwebtoken');
const SECRETKEY = "FPTPOLYTECHNIC"
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await Users.findOne({ username, password })
        if (user) {
            //Token người dùng sẽ sử dụng gửi lên trên header mỗi lần muốn gọi api
            const token = JWT.sign({ id: user._id }, SECRETKEY, { expiresIn: '1h' });
            //Khi token hết hạn, người dùng sẽ call 1 api khác để lấy token mới
            //Lúc này người dùng sẽ truyền refreshToken lên để nhận về 1 cặp token,refreshToken mới
            //Nếu cả 2 token đều hết hạn người dùng sẽ phải thoát app và đăng nhập lại
            const refreshToken = JWT.sign({ id: user._id }, SECRETKEY, { expiresIn: '1d' })
            //expiresIn thời gian token
            res.json({
                "status": 200,
                "messenger": "Đăng nhâp thành công",
                "data": user,
                "token": token,
                "refreshToken": refreshToken
            })
        } else {
            // Nếu thêm không thành công result null, thông báo không thành công
            res.json({
                "status": 400,
                "messenger": "Lỗi, đăng nhập không thành công",
                "data": []
            })
        }
    } catch (error) {
        console.log(error);
    }
})

//search Distributor
router.get('/search-distributor', async (req, res) => {
    try {
        const key = req.query.key

        const data = await Distributors.find({ name: { "$regex": key, "$options": "i" } })
            .sort({ createdAt: -1 });

        if (data) {
            res.json({
                "status": 200,
                "messenger": "Thành công",
                "data": data
            })
        } else {
            res.json({
                "status": 400,
                "messenger": "Lỗi, không thành công",
                "data": []
            })
        }
    } catch (error) {
        console.log(error);
    }
})

//lab 7
//load more
router.get('/get-page-fruit', async (req, res) => {
    //Auten
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401)
    let payload;
    JWT.verify(token, SECRETKEY, (err, _payLoad) => {
        if (err instanceof JWT.TokenExpiredError) return res.sendStatus(401)
        if (err) return res.sendStatus(403)
        payload = _payLoad
    })
    let perPage = 6;
    let page = req.query.page || 1;
    let skip = (perPage * page) - perPage;
    let count = await Furits.find().countDocuments();

    const name = { "$regex": req.query.name ?? "", "$options": "i" }

    const price = { $gte: req.query.price ?? 0 }
    console.log(222, typeof (req.query.sort));

    const sort = { price: Number(req.query.sort) ?? 1 }
    try {
        console.log(1111111, name + "price" + req.query.sort);
        const data = await Furits.find({ name: name, price: price })
            .populate('id_distributor')
            .sort(sort)
            .skip(skip)
            .limit(perPage)
        res.json({
            "status": 200,
            "messenger": "Danh sách fruit",
            "data": {
                "data": data,
                "currentPage": Number(page),
                "totalPage": Math.ceil(count / perPage)
            }
        }
        )

    } catch (err) {
        console.log(err);

    }
})









module.exports = router;